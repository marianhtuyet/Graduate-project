Install the required python libs:

.. code::

  pip install py3o.template
  pip install py3o.formats

To allow the conversion of ODT or ODS reports to other formats (PDF, DOC, DOCX, etc.), install libreoffice:

.. code::

  apt-get --no-install-recommends install libreoffice
