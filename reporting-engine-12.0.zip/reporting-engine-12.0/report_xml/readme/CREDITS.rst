* Icon taken from http://commons.wikimedia.org/wiki/File:Text-xml.svg
