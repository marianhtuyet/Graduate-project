To install this module, you need to:

* Install lxml_ in Odoo's ``$PYTHONPATH``.
* Install the repository `reporting-engine`_.

But this module does nothing for the end user by itself, so if you have it
installed it's probably because there is another module that depends on it.

.. _reporting-engine: https://github.com/OCA/reporting-engine
.. _lxml: http://lxml.de/
