Define KPI dashboard graphs using bokeh.
