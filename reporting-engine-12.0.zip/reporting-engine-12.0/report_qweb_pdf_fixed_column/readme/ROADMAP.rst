* This module is not needed in Odoo 13.0+
