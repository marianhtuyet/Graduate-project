* agr-odoo
* `Tecnativa <https://www.tecnativa.com>`_:

  * Alexandre Díaz
