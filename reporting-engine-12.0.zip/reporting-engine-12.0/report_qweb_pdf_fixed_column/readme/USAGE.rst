The changes are applied to all reports automatically.
