To install this module, you need to install Java JDK Headlees, e.g.:

  apt-get install openjdk-8-jre-headless
