* When signing multiple documents (if 'Allow only one document' is disable)
  then 'Save as attachment' is not applied and signed result is not
  saved as attachment.
* To have a visible signature through an image embedded in the resulting PDF.
* Add tests.
