Example of usage:
https://www.youtube.com/watch?v=OC4-y2klzIk