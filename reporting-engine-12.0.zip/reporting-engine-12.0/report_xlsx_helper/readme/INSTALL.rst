This module requires report_xlsx version 11.0.1.0.3 or higher.
