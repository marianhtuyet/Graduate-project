* You must put this module as `server_wide_modules` in your odoo configuration file
  or add '--load=bi_sql_editor' if you start odoo in command line.
