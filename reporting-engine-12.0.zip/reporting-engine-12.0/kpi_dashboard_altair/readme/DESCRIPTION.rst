Define KPI graphs using altair
