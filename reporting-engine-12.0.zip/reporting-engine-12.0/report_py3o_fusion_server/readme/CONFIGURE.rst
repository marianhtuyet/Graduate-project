To configure the PDF export options:

1. Go to the menu *Settings > Technical > Reporting > Py3o > Py3o PDF Export Options* and create a PDF export options profile.
#. Set the PDF export options profile on the Py3o Server (menu *Settings > Technical > Reporting > Py3o > Py3o Servers*) or on a particular Py3o report with PDF output format (menu *Settings > Technical > Actions > Reports*).
