12.0.1.2
----------

- Non-unicode character support
- Bug fixes

12.0.1.1
----------

- Bug fixes

12.0.1.0
----------

- Release for Odoo 12
