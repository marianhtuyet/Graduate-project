---
name: "\U0001F56E Documentation issue"
about: Ideas/problems with a documentation.

---

**Description**  
<!-- A clear and concise description of the problem/improvement. -->
