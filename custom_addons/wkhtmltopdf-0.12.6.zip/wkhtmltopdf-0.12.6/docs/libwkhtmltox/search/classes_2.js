var searchData=
[
  ['imageglobal',['ImageGlobal',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html',1,'wkhtmltopdf::settings']]]
];
